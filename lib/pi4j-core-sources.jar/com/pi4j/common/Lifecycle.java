package com.pi4j.common;

/*-
 * #%L
 * **********************************************************************
 * ORGANIZATION  :  Pi4J
 * PROJECT       :  Pi4J :: LIBRARY  :: Java Library (CORE)
 * FILENAME      :  Lifecycle.java
 *
 * This file is part of the Pi4J project. More information about
 * this project can be found here:  https://pi4j.com/
 * **********************************************************************
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 * #L%
 */

import com.pi4j.context.Context;
import com.pi4j.exception.InitializeException;
import com.pi4j.exception.ShutdownException;

/**
 * <p>Lifecycle interface.</p>
 *
 * @param <T>
 *
 * @author Robert Savage (<a href="http://www.savagehomeautomation.com">http://www.savagehomeautomation.com</a>)
 * @version $Id: $Id
 */
public interface Lifecycle<T> {

    /**
     * <p>initialize.</p>
     *
     * @param context a {@link com.pi4j.context.Context} object.
     *
     * @return a T object.
     *
     * @throws com.pi4j.exception.InitializeException if an error occurs during initialization.
     */
    T initialize(Context context) throws InitializeException;

    /**
     * This method is called by the registry internally when the registry shutting down and should not be called by
     * users directly. To shut down an IO instance, call close() instead. This will make sure that the
     * instance is not just shut down and closed but also properly unregistered.</p>
     *
     * @param context a {@link com.pi4j.context.Context} object.
     *
     * @return a T object.
     *
     * @throws com.pi4j.exception.ShutdownException if an error occurs during shutdown.
     */
    T shutdownInternal(Context context) throws ShutdownException;
}
